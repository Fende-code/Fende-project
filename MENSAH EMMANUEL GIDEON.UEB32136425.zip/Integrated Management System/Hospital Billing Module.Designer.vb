﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Hospital_Billing_Module
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label1 = New Label()
        txtPatientName = New TextBox()
        Label2 = New Label()
        rbGeneral = New RadioButton()
        rbPrivate = New RadioButton()
        rbSemi = New RadioButton()
        lblDay = New Label()
        chkLab = New CheckBox()
        chkXray = New CheckBox()
        chkSurgery = New CheckBox()
        lblSubtotal = New Label()
        lblTotal = New Label()
        lblVAT = New Label()
        btnCalculate = New Button()
        btnClear = New Button()
        Label7 = New Label()
        Label8 = New Label()
        numDays = New NumericUpDown()
        CType(numDays, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(106, 96)
        Label1.Name = "Label1"
        Label1.Size = New Size(82, 15)
        Label1.TabIndex = 0
        Label1.Text = "Patient Name:"
        ' 
        ' txtPatientName
        ' 
        txtPatientName.Location = New Point(239, 96)
        txtPatientName.Name = "txtPatientName"
        txtPatientName.Size = New Size(371, 23)
        txtPatientName.TabIndex = 1
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(106, 143)
        Label2.Name = "Label2"
        Label2.Size = New Size(65, 15)
        Label2.TabIndex = 2
        Label2.Text = "Ward Type:"
        ' 
        ' rbGeneral
        ' 
        rbGeneral.AutoSize = True
        rbGeneral.BackColor = SystemColors.ButtonHighlight
        rbGeneral.Location = New Point(238, 141)
        rbGeneral.Name = "rbGeneral"
        rbGeneral.Size = New Size(96, 19)
        rbGeneral.TabIndex = 3
        rbGeneral.TabStop = True
        rbGeneral.Text = "General Ward"
        rbGeneral.UseVisualStyleBackColor = False
        ' 
        ' rbPrivate
        ' 
        rbPrivate.AutoSize = True
        rbPrivate.BackColor = SystemColors.ButtonHighlight
        rbPrivate.Location = New Point(512, 141)
        rbPrivate.Name = "rbPrivate"
        rbPrivate.Size = New Size(61, 19)
        rbPrivate.TabIndex = 4
        rbPrivate.TabStop = True
        rbPrivate.Text = "Private"
        rbPrivate.UseVisualStyleBackColor = False
        ' 
        ' rbSemi
        ' 
        rbSemi.AutoSize = True
        rbSemi.BackColor = SystemColors.ButtonHighlight
        rbSemi.Location = New Point(365, 141)
        rbSemi.Name = "rbSemi"
        rbSemi.Size = New Size(92, 19)
        rbSemi.TabIndex = 5
        rbSemi.TabStop = True
        rbSemi.Text = "Semi-Private"
        rbSemi.UseVisualStyleBackColor = False
        ' 
        ' lblDay
        ' 
        lblDay.AutoSize = True
        lblDay.Location = New Point(106, 184)
        lblDay.Name = "lblDay"
        lblDay.Size = New Size(84, 15)
        lblDay.TabIndex = 7
        lblDay.Text = "Days Admited:"
        ' 
        ' chkLab
        ' 
        chkLab.AutoSize = True
        chkLab.Location = New Point(200, 229)
        chkLab.Name = "chkLab"
        chkLab.Size = New Size(140, 19)
        chkLab.TabIndex = 8
        chkLab.Text = "Laboratory Tests (150)"
        chkLab.UseVisualStyleBackColor = True
        ' 
        ' chkXray
        ' 
        chkXray.AutoSize = True
        chkXray.Location = New Point(436, 226)
        chkXray.Name = "chkXray"
        chkXray.Size = New Size(89, 19)
        chkXray.TabIndex = 9
        chkXray.Text = "X-Ray  (100)"
        chkXray.UseVisualStyleBackColor = True
        ' 
        ' chkSurgery
        ' 
        chkSurgery.AutoSize = True
        chkSurgery.Location = New Point(615, 226)
        chkSurgery.Name = "chkSurgery"
        chkSurgery.Size = New Size(110, 19)
        chkSurgery.TabIndex = 10
        chkSurgery.Text = "Surgery    (1000)"
        chkSurgery.UseVisualStyleBackColor = True
        ' 
        ' lblSubtotal
        ' 
        lblSubtotal.AutoSize = True
        lblSubtotal.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblSubtotal.Location = New Point(104, 287)
        lblSubtotal.Name = "lblSubtotal"
        lblSubtotal.Size = New Size(57, 15)
        lblSubtotal.TabIndex = 11
        lblSubtotal.Text = "Subtotal:"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotal.Location = New Point(106, 356)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(57, 15)
        lblTotal.TabIndex = 12
        lblTotal.Text = "Total Bill:"
        ' 
        ' lblVAT
        ' 
        lblVAT.AutoSize = True
        lblVAT.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblVAT.Location = New Point(104, 320)
        lblVAT.Name = "lblVAT"
        lblVAT.Size = New Size(63, 15)
        lblVAT.TabIndex = 13
        lblVAT.Text = "VAT(12%):"
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = Color.FromArgb(CByte(0), CByte(0), CByte(192))
        btnCalculate.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalculate.ForeColor = SystemColors.ButtonHighlight
        btnCalculate.Location = New Point(299, 399)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(130, 23)
        btnCalculate.TabIndex = 14
        btnCalculate.Text = "Calculate Bill"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' btnClear
        ' 
        btnClear.BackColor = Color.FromArgb(CByte(255), CByte(128), CByte(128))
        btnClear.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnClear.Location = New Point(591, 395)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(75, 23)
        btnClear.TabIndex = 15
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = False
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.FromArgb(CByte(255), CByte(255), CByte(192))
        Label7.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.Location = New Point(93, 403)
        Label7.Name = "Label7"
        Label7.Size = New Size(155, 15)
        Label7.TabIndex = 16
        Label7.Text = "Premuium Billing Category"
        ' 
        ' Label8
        ' 
        Label8.BackColor = Color.MidnightBlue
        Label8.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = SystemColors.ButtonHighlight
        Label8.Location = New Point(-1, 1)
        Label8.Name = "Label8"
        Label8.Size = New Size(809, 57)
        Label8.TabIndex = 17
        Label8.Text = "HOSPITAL BILLING MODULE"
        Label8.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' numDays
        ' 
        numDays.Location = New Point(238, 176)
        numDays.Name = "numDays"
        numDays.Size = New Size(81, 23)
        numDays.TabIndex = 18
        ' 
        ' Hospital_Billing_Module
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(255), CByte(224), CByte(192))
        ClientSize = New Size(800, 450)
        Controls.Add(numDays)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(btnClear)
        Controls.Add(btnCalculate)
        Controls.Add(lblVAT)
        Controls.Add(lblTotal)
        Controls.Add(lblSubtotal)
        Controls.Add(chkSurgery)
        Controls.Add(chkXray)
        Controls.Add(chkLab)
        Controls.Add(lblDay)
        Controls.Add(rbSemi)
        Controls.Add(rbPrivate)
        Controls.Add(rbGeneral)
        Controls.Add(Label2)
        Controls.Add(txtPatientName)
        Controls.Add(Label1)
        Name = "Hospital_Billing_Module"
        Text = "Hospital_Billing_Module"
        CType(numDays, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents txtPatientName As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents rbGeneral As RadioButton
    Friend WithEvents rbPrivate As RadioButton
    Friend WithEvents rbSemi As RadioButton
    Friend WithEvents lblDay As Label
    Friend WithEvents chkLab As CheckBox
    Friend WithEvents chkXray As CheckBox
    Friend WithEvents chkSurgery As CheckBox
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents lblVAT As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents numDays As NumericUpDown
End Class
