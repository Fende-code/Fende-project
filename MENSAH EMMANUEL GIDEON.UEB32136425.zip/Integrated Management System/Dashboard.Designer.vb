﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        btnHospital = New Button()
        Label3 = New Label()
        btnLogout = New Button()
        btnstudentloanmodule = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.FromArgb(CByte(255), CByte(192), CByte(128))
        Label1.Font = New Font("Times New Roman", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(316, 85)
        Label1.Name = "Label1"
        Label1.Size = New Size(230, 31)
        Label1.TabIndex = 0
        Label1.Text = "Admin Dashboard"
        ' 
        ' btnHospital
        ' 
        btnHospital.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        btnHospital.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnHospital.Location = New Point(130, 165)
        btnHospital.Name = "btnHospital"
        btnHospital.Size = New Size(218, 158)
        btnHospital.TabIndex = 1
        btnHospital.Text = "Hospital Billing Module"
        btnHospital.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.BackColor = Color.MidnightBlue
        Label3.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = SystemColors.ButtonHighlight
        Label3.Location = New Point(-2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(803, 57)
        Label3.TabIndex = 7
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' btnLogout
        ' 
        btnLogout.BackColor = Color.Gainsboro
        btnLogout.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLogout.Location = New Point(544, 165)
        btnLogout.Name = "btnLogout"
        btnLogout.Size = New Size(205, 158)
        btnLogout.TabIndex = 8
        btnLogout.Text = "Logout"
        btnLogout.UseVisualStyleBackColor = False
        ' 
        ' btnstudentloanmodule
        ' 
        btnstudentloanmodule.BackColor = Color.LightGreen
        btnstudentloanmodule.Font = New Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnstudentloanmodule.Location = New Point(345, 164)
        btnstudentloanmodule.Name = "btnstudentloanmodule"
        btnstudentloanmodule.Size = New Size(205, 159)
        btnstudentloanmodule.TabIndex = 13
        btnstudentloanmodule.TabStop = False
        btnstudentloanmodule.Text = "Student Loan Module"
        btnstudentloanmodule.UseVisualStyleBackColor = False
        ' 
        ' Dashboard
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.FromArgb(CByte(64), CByte(64), CByte(64))
        ClientSize = New Size(800, 450)
        Controls.Add(btnstudentloanmodule)
        Controls.Add(btnLogout)
        Controls.Add(Label3)
        Controls.Add(btnHospital)
        Controls.Add(Label1)
        Name = "Dashboard"
        Text = "Dashboard"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents btnHospital As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnstudentloanmodule As Button
End Class
