﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_Loan_Module
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label8 = New Label()
        Label1 = New Label()
        txtStudentName = New TextBox()
        txtGPA = New TextBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        lblTotal = New Label()
        txtIncome = New TextBox()
        txtLoanAmount = New TextBox()
        btnCalulatePayment = New Button()
        lblMonthly = New Label()
        Label9 = New Label()
        btnBack = New Button()
        SuspendLayout()
        ' 
        ' Label8
        ' 
        Label8.BackColor = Color.MidnightBlue
        Label8.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = SystemColors.ButtonHighlight
        Label8.Location = New Point(-3, 0)
        Label8.Name = "Label8"
        Label8.Size = New Size(809, 57)
        Label8.TabIndex = 18
        Label8.Text = "STUDENT LOAN MODULE"
        Label8.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(70, 82)
        Label1.Name = "Label1"
        Label1.Size = New Size(86, 15)
        Label1.TabIndex = 19
        Label1.Text = "Student Name:"
        ' 
        ' txtStudentName
        ' 
        txtStudentName.Location = New Point(171, 79)
        txtStudentName.Name = "txtStudentName"
        txtStudentName.Size = New Size(253, 23)
        txtStudentName.TabIndex = 20
        ' 
        ' txtGPA
        ' 
        txtGPA.Location = New Point(171, 126)
        txtGPA.Name = "txtGPA"
        txtGPA.Size = New Size(152, 23)
        txtGPA.TabIndex = 21
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(70, 134)
        Label2.Name = "Label2"
        Label2.Size = New Size(32, 15)
        Label2.TabIndex = 22
        Label2.Text = "GPA:"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(70, 191)
        Label3.Name = "Label3"
        Label3.Size = New Size(129, 15)
        Label3.TabIndex = 23
        Label3.Text = "Annual Family Income:"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(70, 239)
        Label4.Name = "Label4"
        Label4.Size = New Size(137, 15)
        Label4.TabIndex = 24
        Label4.Text = "Loan Amount  Reqested:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(70, 286)
        Label5.Name = "Label5"
        Label5.Size = New Size(118, 15)
        Label5.TabIndex = 25
        Label5.Text = "Monthly Repayment:"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Location = New Point(70, 331)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(98, 15)
        lblTotal.TabIndex = 26
        lblTotal.Text = "Total Repayment:"
        ' 
        ' txtIncome
        ' 
        txtIncome.Location = New Point(214, 183)
        txtIncome.Name = "txtIncome"
        txtIncome.Size = New Size(91, 23)
        txtIncome.TabIndex = 27
        ' 
        ' txtLoanAmount
        ' 
        txtLoanAmount.Location = New Point(213, 236)
        txtLoanAmount.Name = "txtLoanAmount"
        txtLoanAmount.Size = New Size(92, 23)
        txtLoanAmount.TabIndex = 28
        ' 
        ' btnCalulatePayment
        ' 
        btnCalulatePayment.BackColor = Color.Blue
        btnCalulatePayment.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalulatePayment.ForeColor = SystemColors.ButtonHighlight
        btnCalulatePayment.Location = New Point(171, 401)
        btnCalulatePayment.Name = "btnCalulatePayment"
        btnCalulatePayment.Size = New Size(157, 23)
        btnCalulatePayment.TabIndex = 31
        btnCalulatePayment.Text = "Calculate Repayment"
        btnCalulatePayment.UseVisualStyleBackColor = False
        ' 
        ' lblMonthly
        ' 
        lblMonthly.AutoSize = True
        lblMonthly.Location = New Point(214, 286)
        lblMonthly.Name = "lblMonthly"
        lblMonthly.Size = New Size(28, 15)
        lblMonthly.TabIndex = 34
        lblMonthly.Text = "0.00"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(213, 331)
        Label9.Name = "Label9"
        Label9.Size = New Size(28, 15)
        Label9.TabIndex = 35
        Label9.Text = "0.00"
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Black
        btnBack.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnBack.ForeColor = SystemColors.ButtonHighlight
        btnBack.Location = New Point(459, 401)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(91, 23)
        btnBack.TabIndex = 36
        btnBack.Text = "Back"
        btnBack.UseVisualStyleBackColor = False
        ' 
        ' Student_Loan_Module
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Cyan
        BackgroundImage = My.Resources.Resources.pngtree_a_focused_student_researching_loans_on_laptop_image_162203011
        ClientSize = New Size(800, 450)
        Controls.Add(btnBack)
        Controls.Add(Label9)
        Controls.Add(lblMonthly)
        Controls.Add(btnCalulatePayment)
        Controls.Add(txtLoanAmount)
        Controls.Add(txtIncome)
        Controls.Add(lblTotal)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(txtGPA)
        Controls.Add(txtStudentName)
        Controls.Add(Label1)
        Controls.Add(Label8)
        Name = "Student_Loan_Module"
        Text = "Student_Loan_Module"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label8 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtStudentName As TextBox
    Friend WithEvents txtGPA As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents txtIncome As TextBox
    Friend WithEvents txtLoanAmount As TextBox
    Friend WithEvents btnCalulatePayment As Button
    Friend WithEvents lblMonthly As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btnBack As Button
End Class
