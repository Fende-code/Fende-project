﻿Public Class Studentloanform
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click

        Dim gpa As Double = txtGPA.Text
        Dim income As Double = btnCheck.Text

        If gpa >= 2.5 And income < 40000 Then

            MessageBox.Show("Student Eligible")
            btnCalculate.Enabled = True

        Else

            MessageBox.Show("Loan Application Rejected")
            btnCalculate.Enabled = False

        End If

    End Sub


    Private Sub btnRepayment_Click(sender As Object, e As EventArgs) Handles txtAmount.Click

        Dim P As Double = txtAmount.Text
        Dim r As Double = 0.08 / 12
        Dim n As Integer = 60

        Dim monthly As Double

        monthly = (P * r * (1 + r) ^ n) / ((1 + r) ^ n - 1)

        Dim total As Double = monthly * n

        lblMonthly.Text = monthly.ToString("F2")
        lblTotal.Text = total.ToString("F2")
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub
End Class
