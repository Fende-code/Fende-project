﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Studentloanform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Label3 = New Label()
        Label1 = New Label()
        Label2 = New Label()
        txtStudent = New TextBox()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        txtGPA = New TextBox()
        txtIcome = New TextBox()
        txtAmount = New TextBox()
        btnCheck = New Button()
        btnCalculate = New Button()
        lblMonthly = New Label()
        lblTotal = New Label()
        SuspendLayout()
        ' 
        ' Label3
        ' 
        Label3.BackColor = Color.FromArgb(CByte(0), CByte(0), CByte(192))
        Label3.Font = New Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = SystemColors.ButtonHighlight
        Label3.Location = New Point(-5, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(803, 57)
        Label3.TabIndex = 8
        Label3.Text = "STUDENT LOAN MODULE"
        Label3.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(26, 71)
        Label1.Name = "Label1"
        Label1.Size = New Size(0, 15)
        Label1.TabIndex = 9
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(18, 76)
        Label2.Name = "Label2"
        Label2.Size = New Size(91, 15)
        Label2.TabIndex = 10
        Label2.Text = "Student Name:"
        ' 
        ' txtStudent
        ' 
        txtStudent.Location = New Point(114, 73)
        txtStudent.Name = "txtStudent"
        txtStudent.Size = New Size(382, 23)
        txtStudent.TabIndex = 11
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(18, 110)
        Label4.Name = "Label4"
        Label4.Size = New Size(33, 15)
        Label4.TabIndex = 12
        Label4.Text = "GPA:"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(12, 156)
        Label5.Name = "Label5"
        Label5.Size = New Size(90, 15)
        Label5.TabIndex = 13
        Label5.Text = "Family Income:"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(12, 201)
        Label6.Name = "Label6"
        Label6.Size = New Size(84, 15)
        Label6.TabIndex = 14
        Label6.Text = "Loan Amount:"
        ' 
        ' txtGPA
        ' 
        txtGPA.Location = New Point(114, 110)
        txtGPA.Name = "txtGPA"
        txtGPA.Size = New Size(135, 23)
        txtGPA.TabIndex = 15
        ' 
        ' txtIcome
        ' 
        txtIcome.Location = New Point(114, 153)
        txtIcome.Name = "txtIcome"
        txtIcome.Size = New Size(135, 23)
        txtIcome.TabIndex = 16
        ' 
        ' txtAmount
        ' 
        txtAmount.Location = New Point(114, 197)
        txtAmount.Name = "txtAmount"
        txtAmount.Size = New Size(135, 23)
        txtAmount.TabIndex = 17
        ' 
        ' btnCheck
        ' 
        btnCheck.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(128))
        btnCheck.Font = New Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCheck.Location = New Point(114, 249)
        btnCheck.Name = "btnCheck"
        btnCheck.Size = New Size(174, 28)
        btnCheck.TabIndex = 18
        btnCheck.Text = "Check Eligibility"
        btnCheck.UseVisualStyleBackColor = False
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = Color.FromArgb(CByte(128), CByte(255), CByte(128))
        btnCalculate.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnCalculate.Location = New Point(314, 249)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(182, 28)
        btnCalculate.TabIndex = 19
        btnCalculate.Text = "Calculate Repayment"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' lblMonthly
        ' 
        lblMonthly.AutoSize = True
        lblMonthly.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblMonthly.Location = New Point(114, 310)
        lblMonthly.Name = "lblMonthly"
        lblMonthly.Size = New Size(123, 15)
        lblMonthly.TabIndex = 20
        lblMonthly.Text = "Monthly Repayment:"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTotal.Location = New Point(352, 310)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(104, 15)
        lblTotal.TabIndex = 21
        lblTotal.Text = "Total Repayment:"
        ' 
        ' Studentloanform
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(708, 349)
        Controls.Add(lblTotal)
        Controls.Add(lblMonthly)
        Controls.Add(btnCalculate)
        Controls.Add(btnCheck)
        Controls.Add(txtAmount)
        Controls.Add(txtIcome)
        Controls.Add(txtGPA)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(txtStudent)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(Label3)
        Name = "Studentloanform"
        Text = "Student LoanForm"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtStudent As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtGPA As TextBox
    Friend WithEvents txtIcome As TextBox
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents btnCheck As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblMonthly As Label
    Friend WithEvents lblTotal As Label
End Class
