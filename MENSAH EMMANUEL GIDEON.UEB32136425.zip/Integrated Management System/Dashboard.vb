﻿Public Class Dashboard
    Private Sub Dashboard_FormClosed(sender As Object, e As EventArgs) Handles Me.FormClosed
        Application.Exit()

    End Sub

    Private Sub btnHospitalBilling_Click(sender As Object, e As EventArgs) Handles btnHospital.Click
        Hospital_Billing_Module.Show()



    End Sub



    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        btnLogout.Show()
        Me.Hide()


    End Sub



    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub






    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnstudentloanmodule.Click
        Studentloanform.Show()

    End Sub
End Class