﻿Public Class Hospital_Billing_Module
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Hospital_Billing_Module_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles lblSubtotal.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblDay.Click

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim wardRate As Double = 0
        Dim days As Integer = numDays.Value
        Dim wardCharges As Double
        Dim treatmentCharges As Double = 0
        Dim subtotal As Double
        Dim vat As Double
        Dim total As Double

        'Ward Type
        If rbGeneral.Checked Then
            wardRate = 200
        ElseIf rbSemi.Checked Then
            wardRate = 350
        ElseIf rbPrivate.Checked Then
            wardRate = 500
        End If

        wardCharges = wardRate * days

        'Optional Services
        If chkLab.Checked Then
            treatmentCharges += 150
        End If

        If chkXray.Checked Then
            treatmentCharges += 100
        End If

        If chkSurgery.Checked Then
            treatmentCharges += 1000
        End If

        subtotal = wardCharges + treatmentCharges

        vat = subtotal * 0.12

        total = subtotal + vat

        lblSubtotal.Text = subtotal.ToString()
        lblVAT.Text = vat.ToString()
        lblTotal.Text = total.ToString()

        If total > 5000 Then
            MessageBox.Show("Premium Billing Category")
        End If
    End Sub

    Private Sub txtPatientName_TextChanged(sender As Object, e As EventArgs) Handles txtPatientName.TextChanged

    End Sub

    Private Sub numDays_ValueChanged(sender As Object, e As EventArgs) Handles numDays.ValueChanged

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        Me.Controls.Clear()

    End Sub
End Class