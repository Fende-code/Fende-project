﻿Public Class Student_Loan_Module
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalulatePayment.Click
        Dim gpa As Double = txtGPA.Text
        Dim income As Double = txtIncome.Text

        If gpa >= 2.5 And income < 40000 Then

            MessageBox.Show("Student Eligible")
            btnCalulatePayment.Enabled = True

        Else

            MessageBox.Show("Loan Application Rejected")
            btnCalulatePayment.Enabled = False


        End If

    End Sub


    Private Sub btncheck_Click(sender As Object, e As EventArgs) Handles btnCalulatePayment.Click

        Dim P As Double = txtLoanAmount.Text
        Dim r As Double = 0.08 / 12
        Dim n As Integer = 60

        Dim monthly As Double

        monthly = (P * r * (1 + r) ^ n) / ((1 + r) ^ n - 1)

        Dim total As Double = monthly * n

        lblMonthly.Text = monthly.ToString("F2")
        lblTotal.Text = total.ToString("F2")

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
    End Sub
End Class